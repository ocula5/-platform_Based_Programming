import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;
enum Command {ADD, LIST, SUM, MIN, MAX, INVALID, QUIT}
public class ArrayEnum {
    public static void main(String[] args){
        int index = 0;
        int[] values = new int[100];
        final Scanner scanner = new Scanner(System.in);
        while(true) {
            final Command command = getCommand(scanner);
            if(command == Command.QUIT){
                System.out.println("Bye!");
                break;
            }
            switch(command){
                case ADD:
                    final int newValue = getValue(scanner);
                    values[index] = newValue;
                    index++;
                    break;
                case LIST:
                    printList(values, index);
                    break;
                case SUM:
                    System.out.println(getSum(values, index));
                    break;
                case MIN:
                    int min = 500000;
                    for(int i = 0; i < index; i++){
                        if(values[i] < min){
                            min = values[i];
                        }
                    }
                    System.out.println(min);
                    break;
                case MAX:
                    int max = Arrays.stream(values).max().getAsInt();
                    System.out.println(max);
                    break;
                case INVALID:
                    System.out.println("Invalid Command");
                    break;
            }
        }
        scanner.close();
    }
    public static Command getCommand(Scanner scanner){
        String order;
        order = scanner.next();
        String command = order.toUpperCase(Locale.ROOT);
        if(command.equals("ADD") || command.equals("LIST") || command.equals("SUM") || command.equals("MIN") || command.equals("MAX") || command.equals("QUIT")){
            return Command.valueOf(command);
        }
        else{
            return Command.INVALID;
        }
    }
    public static int getValue(Scanner scanner){
        return scanner.nextInt();
    }
    public static int getSum(int[] values, int index){
        int sum = 0;
        for(int i = 0; i < index; i++){
            sum += values[i];
        }
        return sum;
    }
    public static void printList(int[] values, int index) {
        for(int i = 0; i < index; i++){
            System.out.print(values[i] +" ");
        }
        System.out.println();
    }

}
