import java.util.Scanner;
public class FactorialMain {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.print("Enter a number : ");
        n = sc.nextInt();
        long result;
        for(int i = 1; i < n+1; i++){
            result = getFactorial(i);
            System.out.println("Factorial of " + i + " = " + result);
        }
    }
    private static long getFactorial(final int n){
        if(n == 1){
            return 1;
        }
        return n * getFactorial(n-1);
    }
}
