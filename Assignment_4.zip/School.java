public class School {
    private String name;
    private int limit;
    private Student[] students;

    public School(String pnu, int i) {
        name = pnu;
        limit = i;
        students = new Student[limit];
    }

    private int studentCount = 0;

    public String toString() {
        String msg = "School Name: " + name + " Student Count: " + studentCount + "\n";
        for(int i = 0; i < studentCount; i++) {
            msg += "\t" + students[i] + "\n";
        }
        return msg;
    }

    public Student findStudent(String studentName, int schoolYear) {
        Student tmp = new Student(studentName, schoolYear);
        int findcode = tmp.hashCode();
        for(int i = 0; i < studentCount; i++)
            if (students[i].hashCode() == findcode) {
                return students[i];
            }
        return null;
    }

    public void removeAllStudent() {
        for(int i = 0; i < 100; i++) {
            students[i] = null;
        }
        studentCount = 0;
    }

    public void addStudent(Student newStudent) {
        students[studentCount] = newStudent;
        studentCount++;
    }
    @Override
    public boolean equals(Object o) {
        return false;
    }
}
