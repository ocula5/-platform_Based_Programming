public class Student {
    private String name;
    private int year;


    public Student(String studentName, int schoolYear) {
        name = studentName; year = schoolYear;
    }

    public int hashCode(){
        return name.hashCode() + year;
    }

    @Override
    public String toString(){
        return String.format("[%s, %d학년]",name, year);
    }
    @Override
    public boolean equals(Object o) {
        if (o instanceof Student) {
            return this.hashCode() == o.hashCode();
        }
        return false;
    }
}
