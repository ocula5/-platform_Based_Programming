import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

enum StringCommand {ADD, REMOVE, CLEAN, QUIT, INVALID}
public class StringSetManager {
    public static void main(String[] args){
        final Scanner scanner = new Scanner(System.in);
        List<String> stringSet = new ArrayList<>(100);
        while(true){
            final StringCommand command = getCommand(scanner);
            if (command == StringCommand.QUIT) {
                System.out.println("BYE!"); break;
            }
            switch(command){
                case ADD: {
                    final String str = getString(scanner);
                    stringSet = add(stringSet, str);
                    print(stringSet);
                    break;
                }
                case REMOVE: {
                    final String str = getString(scanner);
                    stringSet = remove(stringSet,str);
                    print(stringSet);
                    break;
                }
                case CLEAN: {
                    clear(stringSet);
                    print(stringSet);
                    break;
                }
                case INVALID: {
                    System.out.println("Unknown Command!");
                    break;
                }
                default:
                    break;
            }
        }
    }
    public static StringCommand getCommand(Scanner scanner){
        String order = scanner.next();
        String cmd = order.toUpperCase(Locale.ROOT);
        if(cmd.equals("ADD") || cmd.equals("REMOVE") || cmd.equals("CLEAN") || cmd.equals("QUIT")){
            return StringCommand.valueOf(cmd);
        }
        else{
            return StringCommand.INVALID;
        }
    }
    public static String getString(Scanner scanner){
        return scanner.next();
    }
    public static List<String> add(List<String> stringSet, String str){
        if(!stringSet.contains(str)){
            stringSet.add(str);
            return stringSet;
        }
        else{
            return stringSet;
        }
    }
    public static List<String> remove(List<String> stringSet, String str){
        stringSet.remove(str);
        return stringSet;
    }
    public static void clear(List<String> stringSet){
        stringSet.clear();
    }
    public static void print(List<String> stringSet){
        System.out.print("Element Size: " + stringSet.size() + ", Values = ");
        System.out.println(stringSet);
    }
}
