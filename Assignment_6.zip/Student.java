package edu.pnu.admin;

public class Student{
    private final String name;
    private int year;
    private final School theSchool;

    public Student(String studentName, int schoolYear) {
        this.name = studentName; this.year = schoolYear;
        this.theSchool = new School("pnu", 100);
    }

    @Override
    public int hashCode() {
        return name.hashCode() + this.year;
    }
    @Override
    public String toString() {
        return String.format("[%s, %d학년]",this.name, this.year);
    }
}
