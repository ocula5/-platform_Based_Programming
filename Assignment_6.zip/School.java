package edu.pnu.admin;

import edu.pnu.collection.GenericList;

public class School {
    private final String name;
    private GenericList<Student> students = new GenericList<Student> ();

    public School(final String name, int size) {this.name = name; this.students.setSize(size);}
    public String getName() {
        return this.name;
    }

    public void addStudent(Student newStudent) {
        students.add(newStudent);
    }

    public void removeAllStudent() {
        students.remove();
    }

    public Student findStudent(String studentName, int schoolYear) {
        Student found = new Student(studentName, schoolYear);
        for(int i = 0; i < students.index(); i++)
            if(students.get(i).hashCode() == found.hashCode()) {
                return students.get(i);
            }
            return null;
    }
    @Override
    public String toString() {
        String str = String.format("School name: %s Student Count: %d\n",this.name,this.students.index());
        for(int i = 0; i < students.index(); i++) {
            str += students.get(i).toString() + "\n";
        }
        return str;
    }
}
