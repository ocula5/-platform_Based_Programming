package edu.pnu.collection;

public class GenericList<T> {
    private static final int DEFAULT_SIZE = 10;
    private Object[] data;
    private int size = 0;
    private int index = 0;

    public GenericList() {
        size = DEFAULT_SIZE;
        data = (T[]) new Object[size];
    }
    public void add(T elements) {
        data[index] = elements;
        index++;
    }
    public void setSize(int num) {
        Object[] newList = new Object[num];
        this.data = newList;
    }
    public void remove() {
        Object[] newList = new Object[DEFAULT_SIZE];
        index = 0;
        data = newList;
    }
    public T get(int index) {
        return (T) data[index];
    }

    public int size() {
        return this.size;
    }

    public int index() {
        return this.index;
    }
}
