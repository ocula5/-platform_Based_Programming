package uk.epl.player;

public class Defender extends Player{
    private float speed;
    private float passing;
    private int STRENGTH_POINT = 10;
    private String job;

    public Defender(String name, int jerseyNumber, int speed, int stamina, int passing) {
        super(name, jerseyNumber, stamina);
        super.setSpeed(speed);
        setStamina(stamina + STRENGTH_POINT);
        super.setPassing(passing);
        this.speed = getSpeed();
        this.passing = getPassing();
        makePosition(0, 0);
        this.job = "Defender";
    }
    @Override
    public Position makePosition(int x, int y){
        return super.makePosition(x, y);
    }

    @Override
    public Position getPosition() {
        return super.getPosition();
    }
    @Override
    public String toString(){
        return String.format("\nPlayer Name = '%s, JerseyNumber=%d Position %s %s SPEED=%.1f, , STAMINA=%.1f, , PASSING=%.1f",super.getName(), getJerseyNumber(),super.printPosition(),this.job,this.speed,super.getStamina(),super.getPassing());
    }
    @Override
    public void moveUp(){
        float move_delta = getMoveDelta();
        position.y = (int)(position.y - move_delta);
        decreaseStamina();
    }
    private float getMoveDelta() {
        return getSpeed()/100 * getStamina()/100;
    }
    private void decreaseStamina() {
        setStamina((int)this.getStamina()-12);
    }
    @Override
    protected float getStamina() {
        return super.getStamina() + STRENGTH_POINT;
    }

    public String getString() {
        return String.format("\nPlayer Name = '%s, JerseyNumber=%d Position %s %s SPEED=%.1f, , STAMINA=%.1f, , PASSING=%.1f",super.getName(), getJerseyNumber(),this.printPosition(),this.job,this.speed,super.getStamina(),this.passing);
    }
}
