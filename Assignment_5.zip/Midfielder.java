package uk.epl.player;

public class Midfielder extends Player{
    private float speed;
    private float passing;
    private int PASSING_POINT = 10;
    private String job;

    public Midfielder(String name, int jerseyNumber, int speed, int stamina, int passing) {
        super(name, jerseyNumber, stamina);
        super.setSpeed(speed);
        super.setPassing(passing + PASSING_POINT);
        setStamina(stamina);
        this.speed = getSpeed();
        this.passing = getPassing();
        makePosition(0, 0);
        this.job = "Midfielder";
    }
    @Override
    public Position makePosition(int x, int y){
        return super.makePosition(x, y);
    }

    @Override
    public Position getPosition() {
        return super.getPosition();
    }
    @Override
    public String toString(){
        return String.format("\nPlayer Name = '%s, JerseyNumber=%d Position %s %s SPEED=%.1f, ,  STAMINA=%.1f, , PASSING=%.1f",super.getName(), getJerseyNumber(),super.printPosition(),this.job,this.speed,super.getStamina(),this.getPassing());
    }
    @Override
    protected float getPassing() {
        return super.getPassing();
    }

    public String getString() {
        return String.format("\nPlayer Name = '%s, JerseyNumber=%d Position %s %s SPEED=%.1f, , STAMINA=%.1f, , PASSING=%.1f",super.getName(), getJerseyNumber(),this.printPosition(),this.job,this.speed,super.getStamina(),this.passing);
    }

}
