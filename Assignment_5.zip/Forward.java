package uk.epl.player;

public class Forward extends Player {
    private float speed;
    private float passing;
    private int ACCELERATION_POINT = 10;
    private String job;

    public Forward(String name, int jerseyNumber, int speed, int stamina, int passing) {
        super(name, jerseyNumber, stamina);
        super.setSpeed(speed + ACCELERATION_POINT);
        super.setPassing(passing);
        setStamina(stamina);
        this.speed = getSpeed();
        this.passing = getPassing();
        this.job = "Forward";
    }
    @Override
    public Position makePosition(int x, int y){
        return super.makePosition(x, y);
    }
    @Override
    public void setPosition(int x, int y){
        this.position.x = x;
        this.position.y = y;
    }
    @Override
    public Position getPosition() {
        return super.getPosition();
    }
    @Override
    public String printPosition(){
        return String.format("(%d, %d)",position.x, position.y);
    }
    @Override
    protected float getSpeed(){
        return super.getSpeed();
    }
    @Override
    public String toString(){
        return String.format("\nPlayer Name = '%s, JerseyNumber=%d Position %s %s SPEED=%.1f, , STAMINA=%.1f, , PASSING=%.1f",super.getName(), getJerseyNumber(),this.printPosition(),this.job,this.speed,super.getStamina(),this.passing);
    }
    @Override
    public String getString() {
        return String.format("\nPlayer Name = '%s, JerseyNumber=%d Position %s %s SPEED=%.1f, , STAMINA=%.1f, , PASSING=%.1f",super.getName(), getJerseyNumber(),this.printPosition(),this.job,this.speed,super.getStamina(),this.passing);
    }
}
