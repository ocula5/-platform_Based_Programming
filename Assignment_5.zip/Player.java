package uk.epl.player;

public abstract class Player {
    private final String name;
    private final int jerseyNumber;
    private final int[] abilities = new int[3];
    final int SPEED = 0; final int STAMINA = 1; final int PASSING = 2;
    Position position;

    Player(String name, int jerseyNumber, int stamina){
        this.name = name;
        this.jerseyNumber = jerseyNumber;
        this.abilities[STAMINA] = stamina;
        this.position = makePosition(0, 0);
    }

    public abstract String getString();

    public class Position{
        public int x;
        public int y;

        public Position(int x, int y) {
            this.x = x; this.y = y;
        }
    }
    public Position makePosition(int x, int y){
        return new Position(x, y);
    }
    public void setPosition(int x, int y){
        this.position.x = x;
        this.position.y = y;
    }
    public Position getPosition() {
        return new Position(position.x, position.y);
    }
    public String printPosition(){
        return String.format("(%d, %d)",position.x, position.y);
    }
    public void moveUp(){
        float move_delta = getMoveDelta();
        position.y = (int)(position.y - move_delta);
        decreaseStamina();
    }
    public String toString(){
        return "\n";
    }
    protected String getName(){
        return this.name;
    }
    public int getJerseyNumber(){
        return this.jerseyNumber;
    }
    private void decreaseStamina() {
        abilities[STAMINA] = abilities[STAMINA] - 2;
    }
    private float getMoveDelta() {
        return 1 + getSpeed()/100 * getStamina()/100;
    }
    protected void setSpeed(int speed){
        abilities[SPEED] = speed;
    }
    protected float getSpeed(){
        return (float) abilities[SPEED];
    }
    protected void setStamina(int stamina){
        abilities[STAMINA] = stamina;
    }
    protected float getStamina() {
        return (float) abilities[STAMINA];
    }
    protected void setPassing(int passing){
        abilities[PASSING] = passing;
    }
    protected float getPassing(){
        return (float) abilities[PASSING];
    }
}
