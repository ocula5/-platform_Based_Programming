package uk.epl.game;

import uk.epl.player.Player;

import java.util.ArrayList;
import java.util.List;

public class Field {
    private List<Player> players = new ArrayList<>();

    public void add(Player newPlayer) {
        players.add(newPlayer);
    }

    public void moveUp(int choosePlayer) {
        for (Player player : players) {
            if (player.getJerseyNumber() == choosePlayer) {
                player.moveUp();
                break;
            }
        }
        System.out.println("");
    }
    public void moveDown(int choosePlayer) {

    }
    public void moveLeft(int choosePlayer) {

    }
    public void moveRight(int choosePlayer) {

    }
    public void start() {
        for(int i = 0; i < players.size(); i++){
            players.get(i).setPosition(34, (i+1)*25);
        }
    }

    public void info() {
        String tmp = "";
        for(int i = 0; i < players.size(); i++){
            tmp += players.get(i).getString();
        }
        System.out.println(tmp);
    }

    public void stop() {
        System.out.println("");
    }
}
